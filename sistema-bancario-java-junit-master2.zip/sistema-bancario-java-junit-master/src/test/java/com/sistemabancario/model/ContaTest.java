package com.sistemabancario.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContaTest {

    @Test
    void setNumeroR1a(){
        final Conta conta = new Conta();
        final String invalido = "123";
        assertThrows( IllegalArgumentException.class, () ->conta.setNumero(invalido));
        final String obtido = conta.getNumero();
        assertNotEquals(invalido, obtido);
    }

    @Test
    void setNumeroR1b(){
        final Conta conta = new Conta();
        final String invalido = "abcde-f";
        assertThrows( IllegalArgumentException.class, () ->conta.setNumero(invalido));
        final String obtido = conta.getNumero();
        assertNotEquals(invalido, obtido);
    }
    @Test
    void isContaCorrenteAoInstanciarConta(){
        final Conta conta = new Conta();
        assertFalse(conta.isPoupanca());

    }
    @Test
    void setLimitePraContaEspecial(){
        final Conta conta =  new Conta();
        conta.setEspecial(true);
        final double esperado = 1000;
        conta.setLimite(esperado);
        assertEquals(esperado, conta.getLimite());
    }
    @Test
    void setLimitePraContaNaoEspecial(){
        final Conta conta =  new Conta();
        conta.setEspecial(false);
        final double esperado = 1000;
      assertThrows(IllegalStateException.class, () -> conta.setLimite(esperado));
    }
    @Test void getSaldoTotaParaContaEspecialComLimiteR6(){
        final Conta conta =  new Conta();
        final double saldo = 1000, limite = 2000;
        final double esperado = 3000;
        conta.setEspecial(true);
        conta.setSaldo(saldo);
        conta.setLimite(limite);
        assertEquals(esperado, conta.getSaldoTotal());


    }

}
