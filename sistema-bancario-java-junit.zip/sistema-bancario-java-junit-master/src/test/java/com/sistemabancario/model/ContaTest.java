package com.sistemabancario.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContaTest {
    
    @Test
    void testAddMovimentacao() {
        //TODO: Você precisa implementar este teste
    }
    
    
}
